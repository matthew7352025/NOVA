-- Minimal NOVA production schema (Supabase/Postgres)
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text unique not null,
  bio text default '',
  avatar_url text,
  created_at timestamptz default now()
);

create table if not exists language_progress (
  user_id uuid references profiles(id) on delete cascade,
  language_code text not null,
  level int default 1,
  xp int default 0,
  streak int default 0,
  completed_modules int[] default '{}',
  updated_at timestamptz default now(),
  primary key(user_id, language_code)
);

create table if not exists friendships (
  requester uuid references profiles(id) on delete cascade,
  addressee uuid references profiles(id) on delete cascade,
  status text not null default 'pending',
  created_at timestamptz default now(),
  primary key(requester, addressee)
);

create table if not exists messages (
  id bigint generated always as identity primary key,
  sender_id uuid references profiles(id) on delete cascade,
  receiver_id uuid references profiles(id) on delete cascade,
  group_id uuid,
  body text not null,
  created_at timestamptz default now()
);

create table if not exists duels (
  id uuid primary key default gen_random_uuid(),
  challenger uuid references profiles(id) on delete cascade,
  opponent uuid references profiles(id) on delete cascade,
  language_code text not null,
  challenger_score int default 0,
  opponent_score int default 0,
  status text default 'waiting',
  created_at timestamptz default now()
);

create table if not exists achievements (
  user_id uuid references profiles(id) on delete cascade,
  achievement_id text not null,
  unlocked_at timestamptz default now(),
  primary key(user_id, achievement_id)
);
