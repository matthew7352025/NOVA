# NOVA — research notes and product roadmap

## What the uploaded video communicates

The video is a very sparse 16:9 title-card style: white canvas, black type, huge centered words, almost no decoration, and a deliberate sense of pause. The type looks closest to the visual language used by Nothing. The exact font cannot be proven from pixels alone; a community reference to Nothing's brand system documents NType82, NDot55/57 and a mono face, and says the type system is used with strict scale/spacing rules.

For the actual NOVA product we therefore use the same principles rather than copying Nothing's logo or proprietary typefaces: monochrome base, oversized editorial headlines, mono micro-labels, thin dividers, sparse accent color, strong spacing and restrained motion. The code uses Inter Tight + JetBrains Mono because they are practical, freely available alternatives. A properly licensed NType/NDot font can be substituted later.

## What users appear to like about Duolingo

- Very low friction: lessons are short and easy to start.
- Instant feedback and visible rewards.
- Streaks create a habit for many learners.
- Friendly, approachable interface.
- Free entry lowers the barrier to starting.

## What users repeatedly complain about

These are user-review themes, not universal facts about every learner:

- Too many ads / monetization interruptions in free use.
- Energy/hearts limiting a learning session even after correct answers.
- Repetition and progression feeling too slow for some learners.
- Gamification can become the goal instead of the language.
- Some learners want more explanations, reference material and practical conversation.

## What NOVA takes from competitors

### Babbel

Take: structured lessons, grammar explanations, practical topics, review and conversation practice.

Avoid: making the product feel like a textbook. Keep the UI as fast and engaging as a modern app.

### Memrise

Take: useful vocabulary, native-speaker audio/video and speaking/listening practice.

Avoid: making vocabulary the entire product; NOVA must connect vocabulary to grammar, sentences and use cases.

### Busuu

Take: explicit levels, CEFR-style milestones and community/social learning.

Avoid: making progress opaque. Every user should understand what they can now do.

### Anki-style systems

Take: spaced review of weak items.

Avoid: turning NOVA into a flashcard manager. Review should be integrated into real lessons.

## NOVA product principles

1. Learning is the primary KPI, not time spent in the app.
2. XP is a signal, not the definition of success.
3. Streaks can motivate but never punish the learner with forced grinding.
4. No hearts/energy barrier during the core lesson.
5. Every wrong answer should teach something.
6. Practice should cover recognition, recall, sentence building, error detection, reading, listening and speaking.
7. The user sees skill progress (grammar, vocabulary, listening, writing, speaking) separately.
8. Social competition is optional and opt-in.
9. Content uses practical situations and natural language.
10. The interface remains calm, premium and readable for different ages.

## Zero-budget development path

1. MacBook M1 + VS Code or Cursor (both can be used during development without buying software).
2. Node.js LTS + Git.
3. GitHub Free for source code and collaboration.
4. GitHub Pages or Cloudflare Pages for the static web frontend.
5. Supabase Free for an early real backend prototype.
6. PWA first. Native iOS/Android packaging comes later with Capacitor.

## Production phases

Phase 1 — Prototype: localStorage, demo users/bots, lessons, teacher KB, translator, duels, analytics.

Phase 2 — Real backend: Auth, profiles, friendship graph, chat, groups, progress sync, achievements, photo storage.

Phase 3 — Content: 9 languages x 24 modules with language-specific content, native audio, CEFR-aligned tests, spaced repetition.

Phase 4 — Quality: analytics, moderation, reporting, privacy controls, backups, rate limiting, monitoring, accessibility.

Phase 5 — Distribution: public PWA, optional native iOS/Android builds, store listings and beta testing.
