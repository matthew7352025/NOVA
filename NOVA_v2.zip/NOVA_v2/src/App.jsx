import React, { useEffect, useMemo, useState } from 'react';

const LANGUAGES = [
  ['en', 'English', '🇬🇧'], ['es', 'Español', '🇪🇸'], ['de', 'Deutsch', '🇩🇪'], ['fr', 'Français', '🇫🇷'],
  ['it', 'Italiano', '🇮🇹'], ['pt', 'Português', '🇵🇹'], ['ja', '日本語', '🇯🇵'], ['ko', '한국어', '🇰🇷'], ['he', 'עברית', '🇮🇱']
];

const MODULES = [
  ['01','Первые слова','Приветствия и вежливость','Starter','hello • please • thanks'],
  ['02','Люди','Семья и знакомство','Starter','I • you • friend • family'],
  ['03','Еда','Кафе, магазин и меню','Starter','order • water • bill • hungry'],
  ['04','Город','Места и маршруты','Starter','street • station • left • right'],
  ['05','Время','Дни, даты и планы','A1','today • tomorrow • at 8'],
  ['06','Фразы','Готовые разговорные конструкции','A1','I would like • Could you…'],
  ['07','Вопросы','Как задавать вопросы','A1','what • where • why • how'],
  ['08','Глаголы','Самые нужные действия','A1','go • come • get • make'],
  ['09','Present Simple','Привычки и факты','A1','do • does • routines'],
  ['10','Past Simple','Что произошло','A2','did • went • saw • was'],
  ['11','Future','Планы и прогнозы','A2','will • going to'],
  ['12','Артикли','a / an / the без зубрёжки','A2','context • specificity'],
  ['13','Предлоги','in / on / at и другие','A2','time • place • movement'],
  ['14','Modal verbs','can • should • must','A2','ability • advice • obligation'],
  ['15','Present Perfect','Опыт и результат','B1','have + V3'],
  ['16','Conditionals','Реальные и нереальные условия','B1','if • would • could'],
  ['17','Phrasal verbs','Живая разговорная речь','B1','give up • figure out'],
  ['18','Идиомы','Фразы, которые нельзя переводить дословно','B1','break the ice • piece of cake'],
  ['19','Ошибки','Учимcя замечать чужие и свои ошибки','B1','its / it’s • your / you’re'],
  ['20','Составление речи','Слова → предложение → мысль','B2','word order • connectors'],
  ['21','Аудирование','Понимание обычной речи','B2','speed • accents • context'],
  ['22','Письмо','Сообщения, письма, тексты','B2','tone • structure • clarity'],
  ['23','Разговор','Реальные жизненные сценарии','B2','travel • work • social'],
  ['24','Финальный уровень','Комплексная проверка','C1','reading • listening • grammar • writing']
];

const ACHIEVEMENTS = [
  ['first','FIRST STEP','Первый завершённый модуль','01'], ['streak7','SEVEN','7 дней подряд','07'], ['level10','LEVEL X','Достигнут 10 уровень','10'],
  ['daily7','DAILY','7 ежедневных заданий','07'], ['duelist','DUELIST','5 дуэлей','05'], ['social','SOCIAL','5 друзей','05'],
  ['polyglot','POLYGLOT','2 языка в обучении','02'], ['grammar','GRAMMAR','90% в грамматике','90'], ['speed','SPEED','Ответ за 3 секунды','03'],
  ['builder','BUILDER','10 предложений собрано','10'], ['observer','OBSERVER','20 ошибок найдено','20'], ['teacher','TEACHER','20 вопросов учителю','20'],
  ['month','MONTH','30 дней подряд','30'], ['champion','CHAMPION','Топ-3','03']
];

const FRIENDS = [
  {nick:'lena.lang', name:'Lena', xp:2810, level:10, progress:74, online:true},
  {nick:'max.words', name:'Max', xp:2550, level:9, progress:61, online:false},
  {nick:'sofia.study', name:'Sofia', xp:2320, level:8, progress:57, online:true},
  {nick:'leo.de', name:'Leo', xp:1980, level:7, progress:49, online:false},
];

const BOTS = [
  {nick:'nova.bot', name:'NOVA Bot', xp:3100, level:12, progress:88, bot:true},
  {nick:'lingua.bot', name:'Lingua', xp:2740, level:11, progress:81, bot:true},
  {nick:'poly.bot', name:'Poly', xp:2210, level:9, progress:66, bot:true},
  {nick:'grammar.bot', name:'Grammar Fox', xp:1840, level:8, progress:58, bot:true},
  {nick:'verba.bot', name:'Verba', xp:1450, level:7, progress:43, bot:true},
];

const TEACHER_KB = {
  'present perfect': 'Present Perfect = have/has + V3. Используем для опыта, результата к настоящему моменту и действий, начавшихся в прошлом и связанных с настоящим. Пример: I have finished my homework.',
  'a/an': 'A/an — неопределённый артикль. Ставится перед исчисляемым существительным в единственном числе, когда предмет не конкретизирован. An зависит от звука: an apple, an hour.',
  'say tell': 'say — акцент на сообщении: She said hello. tell — на адресате: She told me the truth.',
  'should': 'Should — мягкий совет: You should practice every day. Для сильной обязанности чаще нужен must/have to.',
  'past simple': 'Past Simple — законченное действие в прошлом: I visited Rome last year. Для вопросов и отрицаний часто используется did + базовая форма.',
};

const TRANSLATIONS = {
  hello: {ru:'привет', es:'hola', de:'hallo', fr:'bonjour', it:'ciao', pt:'olá', ja:'こんにちは', ko:'안녕하세요', he:'שלום'},
  thanks: {ru:'спасибо', es:'gracias', de:'danke', fr:'merci', it:'grazie', pt:'obrigado', ja:'ありがとう', ko:'감사합니다', he:'תודה'},
  water: {ru:'вода', es:'agua', de:'wasser', fr:'eau', it:'acqua', pt:'água', ja:'水', ko:'물', he:'מים'},
  house: {ru:'дом', es:'casa', de:'haus', fr:'maison', it:'casa', pt:'casa', ja:'家', ko:'집', he:'בית'},
  'how are you': {ru:'как дела', es:'¿cómo estás?', de:'wie geht es dir?', fr:'comment ça va ?', it:'come stai?', pt:'como está?', ja:'元気ですか？', ko:'어떻게 지내세요?', he:'מה שלומך?'}
};

function Icon({type, size=18}) {
  const paths = {
    home:'M3 10.5 12 3l9 7.5v9a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 19.5v-9Zm5 11v-7h8v7',
    book:'M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 1 4 17.5v-13ZM4 17.5A2.5 2.5 0 0 0 6.5 20M8 6h8M8 10h8',
    users:'M16 20v-1.5a4.5 4.5 0 0 0-4.5-4.5h-3A4.5 4.5 0 0 0 4 18.5V20M10 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm8.5 1a3.5 3.5 0 1 0-2.2-6.2M20 20v-1a4 4 0 0 0-3-3.9',
    trophy:'M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4Zm0 1H4v2a4 4 0 0 0 4 4m9-6h3v2a4 4 0 0 1-4 4',
    chart:'M4 19V5M4 19h16M8 16v-3M12 16V8M16 16v-6M20 16v-9',
    translate:'M5 5h9M9 3v2m-1 0c0 4-2 7-5 9m4-5c1 2 2.5 3.6 4.5 5M14 21l5-12 5 12M16 17h6',
    chat:'M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v7a2.5 2.5 0 0 1-2.5 2.5H10l-5 4v-4.8A2.5 2.5 0 0 1 4 12.5v-7Z',
    user:'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 9a7 7 0 0 1 14 0',
    spark:'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Zm7 12 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z',
    play:'M8 5v14l11-7L8 5Z',
    clock:'M12 7v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0',
    search:'M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16Zm6-2 4 4',
    arrow:'M5 12h14M13 6l6 6-6 6',
    check:'m5 12 4 4L19 6',
    close:'M6 6l12 12M18 6 6 18',
    plus:'M12 5v14M5 12h14',
    volume:'M5 10v4h3l4 3V7l-4 3H5Zm10-2a5 5 0 0 1 0 8M17 5a9 9 0 0 1 0 14',
  };
  return <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d={paths[type] || paths.spark}/></svg>
}

function useLocalState(key, fallback) {
  const [value, setValue] = useState(() => {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; }
  });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(value)); } catch {} }, [key, value]);
  return [value, setValue];
}

const initialUser = { nick:'NovaPlayer', name:'Матвей', bio:'Изучаю языки. Люблю хороший дизайн.', xp:1240, level:8, streak:7, friends:4, teacherQuestions:0, daily:0, modulesDone:16, wordsSaved:8 };

function App(){
  const [user,setUser] = useLocalState('nova_user_v2', initialUser);
  const [ach,setAch] = useLocalState('nova_ach_v2', ['first','streak7']);
  const [page,setPage] = useState('home');
  const [lang,setLang] = useLocalState('nova_lang_v2','en');
  const [theme,setTheme] = useLocalState('nova_theme_v2','light');
  const [sound,setSound] = useLocalState('nova_sound_v2', true);
  const [showProfile,setShowProfile] = useState(false);
  const levelPct = Math.min(100, Math.round((user.xp % 300) / 3));

  useEffect(()=>{ document.body.dataset.theme=theme; },[theme]);

  function xp(n){ setUser(u=>({...u,xp:u.xp+n})); }
  function completeModule(){ setUser(u=>({...u, xp:u.xp+70, modulesDone:u.modulesDone+1})); setAch(a=>[...new Set([...a,'first'])]); }
  function daily(){ if(user.daily<7){setUser(u=>({...u,daily:u.daily+1,xp:u.xp+120,streak:Math.max(u.streak+1,8)})); if(user.daily+1>=7)setAch(a=>[...new Set([...a,'daily7'])]);}}

  const nav=[
    ['home','Главная','home'], ['learn','Учиться','book'], ['teacher','Онлайн учитель','spark'], ['translate','Переводчик','translate'],
    ['community','Сообщество','users'], ['duels','Дуэли','trophy'], ['rating','Топ','chart'], ['achievements','Достижения','spark'],
    ['analytics','Аналитика','chart']
  ];

  return <div className="appShell">
    <header className="topbar">
      <button className="brand" onClick={()=>setPage('home')} aria-label="NOVA">NOVA<span className="dotMark">•••</span></button>
      <div className="topActions">
        <div className="microStat"><span className="mono">{user.streak}</span><span>дней</span></div>
        <div className="microStat"><span className="mono">{user.xp}</span><span>XP</span></div>
        <button className="avatarBtn" onClick={()=>setShowProfile(true)} title="Профиль">{user.nick[0].toUpperCase()}</button>
      </div>
    </header>
    <div className="mainLayout">
      <aside className="sidebar">
        <div className="sideSectionLabel">NOVA / LEARN</div>
        {nav.map(([id,label,icon])=><button key={id} className={`navItem ${page===id?'active':''}`} onClick={()=>setPage(id)}><Icon type={icon} size={17}/><span>{label}</span></button>)}
        <div className="sidebarBottom">
          <div className="sideSectionLabel">LAB</div>
          <button className="navItem" onClick={()=>setTheme(theme==='light'?'dark':'light')}><span className="themeSwitch">{theme==='light'?'☼':'◐'}</span><span>{theme==='light'?'Светлая':'Тёмная'}</span></button>
          <button className="navItem" onClick={()=>setSound(!sound)}><Icon type="volume" size={17}/><span>Звук {sound?'вкл':'выкл'}</span></button>
        </div>
      </aside>
      <main className="page">{page==='home'&&<Home user={user} levelPct={levelPct} onDaily={daily} onLearn={()=>setPage('learn')} onTest={()=>setPage('test')} onDuel={()=>setPage('duels')} />}
        {page==='learn'&&<Learn lang={lang} setLang={setLang} onComplete={completeModule}/>} 
        {page==='test'&&<PlacementTest onAward={xp}/>} 
        {page==='teacher'&&<Teacher setUser={setUser}/>} 
        {page==='translate'&&<Translator/>} 
        {page==='community'&&<Community setPage={setPage} setUser={setUser}/>} 
        {page==='duels'&&<Duels setUser={setUser} setAch={setAch}/>} 
        {page==='rating'&&<Rating user={user}/>} 
        {page==='achievements'&&<Achievements ach={ach}/>} 
        {page==='analytics'&&<Analytics user={user}/>} 
      </main>
    </div>
    {showProfile&&<Profile user={user} setUser={setUser} close={()=>setShowProfile(false)} />}
  </div>
}

function PageTitle({eyebrow,title,sub,right}){return <div className="pageTitle"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{sub&&<p>{sub}</p>}</div>{right}</div>}

function Home({user,levelPct,onDaily,onLearn,onTest,onDuel}){
  const dailyDone=user.daily>=7;
  return <div className="stack">
    <section className="heroPanel">
      <div className="heroCopy"><div className="eyebrow">TODAY / {new Date().toLocaleDateString('ru-RU',{day:'2-digit',month:'long'}).toUpperCase()}</div><h1>Учить язык.<br/><span>Действительно.</span></h1><p>Короткие занятия, понятные правила и живые задания — без гонки за цифрами.</p><div className="heroButtons"><button className="primary big" onClick={onLearn}><Icon type="play" size={16}/>Продолжить</button><button className="secondary big" onClick={onTest}>Проверить уровень <Icon type="arrow" size={16}/></button></div></div>
      <div className="heroOrb"><div className="orbInner"><span>LEVEL</span><b>{user.level}</b><small>{levelPct}%</small></div></div>
    </section>
    <div className="metricGrid">
      <Metric title="Серия" value={user.streak} suffix="дн." accent="streak" note="Продолжай каждый день" />
      <Metric title="XP сегодня" value="185" suffix="XP" note="+70 за модуль" />
      <Metric title="До нового уровня" value={`${100-levelPct}%`} suffix="" note="Ещё немного" />
      <Metric title="Друзья" value={user.friends} suffix="" note="2 сейчас онлайн" />
    </div>
    <section className="card largeCard">
      <div className="cardHeader"><div><div className="eyebrow">DAILY / 03</div><h2>Ежедневный ритм</h2></div>{dailyDone?<span className="status success">ГОТОВО</span>:<button className="textBtn" onClick={onDaily}>{user.daily<7?'Забрать +120 XP':'Выполнено'} <Icon type="arrow" size={15}/></button>}</div>
      <div className="dailyGrid"><div className="dailyBig">{String(Math.min(user.daily,7)).padStart(2,'0')}<span>/07</span></div><div><p className="lead">Три небольших действия вместо марафона.</p><div className="steps"><span className="doneDot">01</span><span className={user.daily>=1?'lineDone':''}></span><span className="doneDot">02</span><span className={user.daily>=2?'lineDone':''}></span><span className="doneDot">03</span></div><p className="muted">5 мин · словарь + грамматика + речь</p></div></div>
    </section>
    <div className="splitGrid">
      <section className="card"><div className="eyebrow">CONTINUE</div><h2>Английский</h2><p>Модуль 17 · Фразовые глаголы</p><div className="progressWrap"><div className="progress"><span style={{width:'67%'}}></span></div><b>67%</b></div><button className="inlineAction" onClick={onLearn}>Продолжить <Icon type="arrow" size={15}/></button></section>
      <section className="card darkCard"><div className="eyebrow">VERSUS</div><h2>Быстрая дуэль</h2><p>8 вопросов · 60 секунд · случайный соперник</p><button className="primary" onClick={onDuel}>Найти соперника <Icon type="arrow" size={15}/></button></section>
    </div>
  </div>
}

function Metric({title,value,suffix,note}){return <div className="metric card"><div className="eyebrow">{title}</div><div className="metricVal">{value}<span>{suffix}</span></div><p>{note}</p></div>}

function Learn({lang,setLang,onComplete}){
  const [selected,setSelected]=useState(16); const [mode,setMode]=useState('hub');
  const lc=LANGUAGES.find(x=>x[0]===lang)||LANGUAGES[0];
  return <div className="stack"><PageTitle eyebrow="LEARNING PATH" title="Путь" sub="Не просто список тем. Каждый модуль учит применять язык." right={<button className="secondary" onClick={()=>setMode('review')}>Повторить ошибки</button>}/>
    <section className="languageBar card"><div className="languageIdentity"><span className="flagLarge">{lc[2]}</span><div><b>{lc[1]}</b><small>уровень B1 · 16 из 24 модулей</small></div></div><div className="languagePills">{LANGUAGES.map(l=><button key={l[0]} className={l[0]===lang?'selected':''} onClick={()=>setLang(l[0])}>{l[2]} <span>{l[1]}</span></button>)}</div></section>
    {mode==='review'?<ReviewPanel back={()=>setMode('hub')}/>:<>
    <section className="card pathCard"><div className="pathTop"><div><div className="eyebrow">01 — 24</div><h2>Маршрут обучения</h2></div><div className="pathMeta"><span>8 уровней</span><span>24 модуля</span><span>+ практика</span></div></div>
      <div className="moduleList">{MODULES.map((m,i)=>{const open=i<=16;return <button key={m[0]} className={`moduleRow ${i===selected?'current':''} ${!open?'locked':''}`} onClick={()=>open&&setSelected(i)}>
        <span className="moduleNo">{m[0]}</span><span className="moduleMain"><b>{m[1]}</b><small>{m[2]}</small></span><span className="moduleType">{m[3]}</span><span className="moduleExample">{m[4]}</span><span className="moduleArrow">{open?'→':'○'}</span>
      </button>})}</div>
    </section>
    <Lesson module={MODULES[selected]} onComplete={onComplete}/></>}
  </div>
}

function Lesson({module,onComplete}){
  const [q,setQ]=useState(0); const [chosen,setChosen]=useState([]); const [feedback,setFeedback]=useState(''); const [done,setDone]=useState(false);
  const tasks=[
    {type:'choice',prompt:'Как сказать «Я просыпаюсь в семь»?',options:['I wake up at seven.','I waking up seven.','I wake at seven yesterday.','I am wake up seven.'],answer:0},
    {type:'build',prompt:'Собери предложение',words:['every','I','day','practice','English'],answer:'I practice English every day'},
    {type:'spot',prompt:'Найди ошибку',left:'She go to work every day.',right:'She goes to work every day.',answer:'right'},
  ];
  const t=tasks[q];
  function choice(i){setFeedback(i===t.answer?'correct':'wrong');if(i===t.answer)setTimeout(()=>setQ(x=>Math.min(2,x+1)),350)}
  function toggleWord(w){setChosen(c=>c.includes(w)?c.filter(x=>x!==w):[...c,w])}
  function submitBuild(){const s=chosen.join(' ');setFeedback(s===t.answer?'correct':'wrong');if(s===t.answer)setTimeout(()=>setQ(2),350)}
  function spot(v){setFeedback(v===t.answer?'correct':'wrong');if(v===t.answer)setTimeout(()=>{setDone(true)},350)}
  return <section className="card lessonCard"><div className="lessonHeader"><div><div className="eyebrow">MODULE {module?.[0]||'—'}</div><h2>{module?.[1]}</h2><p>{module?.[2]}</p></div><div className="questionCounter">{String(q+1).padStart(2,'0')} / 03</div></div>
    {done?<div className="completeState"><div className="completeMark">✓</div><h2>Готово.</h2><p>Модуль завершён. +70 XP. Теперь то же правило появится позже в повторении.</p><button className="primary" onClick={onComplete}>Забрать награду</button></div>:<div className="taskArea"><div className="taskPrompt">{t.prompt}</div>{t.type==='choice'&&<div className="choiceGrid">{t.options.map((o,i)=><button key={o} className={`choiceBtn ${feedback && i===t.answer&&feedback==='correct'?'correct':''} ${feedback==='wrong'&&i!==t.answer?'wrong':''}`} onClick={()=>choice(i)}>{o}<span>{String(i+1).padStart(2,'0')}</span></button>)}</div>}
    {t.type==='build'&&<><div className="answerLine">{chosen.map((w,i)=><span key={i}>{w}</span>)}</div><div className="wordBank">{t.words.map((w,i)=><button key={i} className={chosen.includes(w)?'used':''} onClick={()=>toggleWord(w)}>{w}</button>)}</div><button className="primary" onClick={submitBuild}>Проверить</button></>}
    {t.type==='spot'&&<div className="spotGrid"><button className="spotCard" onClick={()=>spot('left')}><span className="eyebrow">ОШИБОЧНО</span>{t.left}</button><button className="spotCard" onClick={()=>spot('right')}><span className="eyebrow">ПРАВИЛЬНО</span>{t.right}</button></div>}
    {feedback&&<div className={`feedback ${feedback}`}>{feedback==='correct'?'Верно. Дальше.':'Почти. Посмотри на форму ещё раз.'}</div>}</div>}
  </section>
}

function ReviewPanel({back}){return <section className="card"><div className="row"><div><div className="eyebrow">SMART REVIEW</div><h2>Твои ошибки</h2><p>Повторяем не всё подряд, а то, что действительно даётся сложнее.</p></div><button className="secondary" onClick={back}>Назад</button></div><div className="reviewList">{[['Present Perfect','42%','Использование'],['in / on / at','58%','Предлоги'],['its / it’s','61%','Правописание'],['word order','67%','Составление']].map(x=><div className="reviewRow" key={x[0]}><b>{x[0]}</b><span>{x[2]}</span><div className="miniProgress"><i style={{width:x[1]}}></i></div><em>{x[1]}</em></div>)}</div></section>}

function PlacementTest({onAward}){const [step,setStep]=useState(0);const [score,setScore]=useState(0);const qs=[
 ['I ___ coffee every morning.',['drink','drinks','drinking','drank'],0],['She has ___ idea.',['a','an','the','—'],1],['If I have time, I ___ call you.',['would','will','called','calling'],1],
 ['I have lived here ___ 2020.',['for','since','during','from'],1],['Choose the natural sentence.',['I already finished it.','Already I finish it.','I finish it yesterday.','I have finish it.'],0],['Which is closest to “I’m looking forward to it”?',['Я боюсь этого','Я с нетерпением этого жду','Я уже это сделал','Я не уверен'],1],
 ['What does “figure out” mean?',['забыть','разобраться','поторопиться','вернуться'],1],['Choose the correct conditional.',['If I knew, I would tell you.','If I know, I would told you.','If I knew, I will tell.','If I know, I told you.'],0],['Natural spoken English:',['Could you give me a hand?','Could you give my hand?','Can you a hand?','You give hand me?'],0]
];
 if(step>=qs.length)return <div className="stack"><PageTitle eyebrow="PLACEMENT / RESULT" title="Твой уровень — B1" sub={`Правильных ответов: ${score} из ${qs.length}. Тест проверил лексику, грамматику и контекст.`}/><section className="card resultCard"><div className="resultNumber">B1</div><div><h2>Уверенная база</h2><p>Ты уже можешь понимать повседневную речь и строить связные фразы. Следующая задача — точность, скорость и разговорная практика.</p><button className="primary" onClick={()=>{onAward(100);setStep(0);setScore(0)}}>Начать маршрут</button></div></section></div>
 const [prompt,opts,ans]=qs[step]; return <div className="stack"><PageTitle eyebrow="PLACEMENT TEST" title="Серьёзная проверка" sub="9 демонстрационных вопросов из расширенного адаптивного теста. В полном режиме — 18 вопросов на каждый язык."/><section className="card testCard"><div className="testTop"><div className="mono">{String(step+1).padStart(2,'0')} / {String(qs.length).padStart(2,'0')}</div><div className="progressWrap"><div className="progress"><span style={{width:`${((step)/qs.length)*100}%`}}></span></div></div></div><h2>{prompt}</h2><div className="choiceGrid">{opts.map((o,i)=><button key={o} className="choiceBtn" onClick={()=>{if(i===ans)setScore(s=>s+1);setStep(s=>s+1)}}>{o}<span>{String(i+1).padStart(2,'0')}</span></button>)}</div></section></div>
}

function Teacher({setUser}){const [input,setInput]=useState(''); const [msgs,setMsgs]=useState([{r:'ai',t:'Привет. Я Онлайн учитель NOVA. Я работаю на предварительно загруженной базе знаний и объясняю правила простым языком.'}]);
 function send(){const q=input.trim();if(!q)return;let a='В моей базе пока нет точного ответа на этот вопрос. Спроси про Present Perfect, a/an, should, Past Simple или say/tell.';const l=q.toLowerCase();if(l.includes('present perfect'))a=TEACHER_KB['present perfect'];else if(l.includes('a/an')||l.includes('артик'))a=TEACHER_KB['a/an'];else if(l.includes('say')||l.includes('tell'))a=TEACHER_KB['say tell'];else if(l.includes('should'))a=TEACHER_KB.should;else if(l.includes('past simple'))a=TEACHER_KB['past simple'];setMsgs(m=>[...m,{r:'me',t:q},{r:'ai',t:a}]);setInput('');setUser(u=>({...u,teacherQuestions:u.teacherQuestions+1}));}
 return <div className="stack"><PageTitle eyebrow="OFFLINE TEACHER" title="Онлайн учитель" sub="Не чат с внешним API. Быстрая учебная база: правило → пример → объяснение."/><section className="teacherLayout"><section className="card teacherCard"><div className="teacherHead"><div className="teacherAvatar">N</div><div><b>NOVA Teacher</b><small>Учитель языка · offline knowledge</small></div><span className="status success">ONLINE</span></div><div className="chatLog">{msgs.map((m,i)=><div key={i} className={`chatBubble ${m.r}`}>{m.t}</div>)}</div><div className="teacherInput"><input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Например: чем отличается Past Simple?"/><button className="primary" onClick={send}>Спросить</button></div></section><aside className="card teacherAside"><div className="eyebrow">TOPICS</div><h3>Что можно спросить</h3>{['Present Perfect','Артикли a/an','say vs tell','Past Simple','Should / must'].map(x=><button className="topicBtn" key={x} onClick={()=>setInput(x)}>{x}<Icon type="arrow" size={14}/></button>)}</aside></section></div>
}

function Translator(){const [q,setQ]=useState('');const [from,setFrom]=useState('ru');const [to,setTo]=useState('en');const result=useMemo(()=>{const s=q.trim().toLowerCase();if(!s)return '';for(const v of Object.values(TRANSLATIONS)){if(v[from]===s)return v[to]||'';if(v.ru===s&&from==='ru')return v[to]||'';if(v.en===s&&from==='en')return v[to]||'';}return '';},[q,from,to]);
 return <div className="stack"><PageTitle eyebrow="TRANSLATE" title="Переводчик" sub="База коротких слов и фраз на 9 языках. Дальше можно заменить локальный слой на полноценный translation API."/><section className="card translator"><div className="translateSelect"><select value={from} onChange={e=>setFrom(e.target.value)}>{[['ru','Русский'],...LANGUAGES.map(l=>[l[0],l[1]])].map(x=><option value={x[0]} key={x[0]}>{x[1]}</option>)}</select><button className="swap" onClick={()=>{const a=from;setFrom(to);setTo(a)}}>↔</button><select value={to} onChange={e=>setTo(e.target.value)}>{[['ru','Русский'],...LANGUAGES.map(l=>[l[0],l[1]])].map(x=><option value={x[0]} key={x[0]}>{x[1]}</option>)}</select></div><div className="translateGrid"><textarea value={q} onChange={e=>setQ(e.target.value)} placeholder="Введите слово или короткую фразу…"/><div className="translationResult"><span className="eyebrow">RESULT</span><div>{result||'—'}</div>{result&&<button className="iconAction" onClick={()=>speechSynthesis.speak(new SpeechSynthesisUtterance(result))}><Icon type="volume" size={18}/></button>}</div></div><div className="suggestions">{['привет','спасибо','вода','дом','как дела'].map(x=><button key={x} onClick={()=>setQ(x)}>{x}</button>)}</div></section></div>
}

function Community({setPage,setUser}){const [query,setQuery]=useState('');const [chat,setChat]=useState(null);const people=[...FRIENDS,...BOTS].filter(p=>p.nick.includes(query.toLowerCase())||p.name.toLowerCase().includes(query.toLowerCase()));function add(){setUser(u=>({...u,friends:u.friends+1}));}return <div className="stack"><PageTitle eyebrow="COMMUNITY" title="Люди" sub="Друзья, прогресс и соревнования без лишнего шума."/><section className="card searchCard"><Icon type="search" size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Найти по имени или никнейму…"/></section><section className="socialGrid"><section className="card"><div className="cardHeader"><div><div className="eyebrow">PEOPLE</div><h2>Игроки</h2></div><span className="tag">{people.length}</span></div>{people.map(p=><div className="personRow" key={p.nick}><div className="avatarMini">{p.name[0]}</div><div className="personMain"><b>{p.nick}{p.bot&&<small className="botTag">BOT</small>}</b><span>{p.name} · уровень {p.level} · {p.progress}% пути</span></div><div className="personActions"><button className="secondary smallBtn" onClick={()=>add()}><Icon type="plus" size={14}/></button><button className="primary smallBtn" onClick={()=>setChat(p)}>Чат</button></div></div>)}</section><section className="card darkCard"><div className="eyebrow">YOUR CIRCLE</div><h2>Твои друзья</h2><div className="friendCount">04</div><p>3 друга сегодня занимались. Можно бросить вызов прямо из профиля.</p><button className="primary" onClick={()=>setPage('duels')}>Открыть дуэли <Icon type="arrow" size={15}/></button></section></section>{chat&&<ChatModal person={chat} close={()=>setChat(null)}/>}</div>}

function ChatModal({person,close}){const [msgs,setMsgs]=useState([{r:'ai',t:`Привет! Я ${person.name}. Готов к дуэли?`}]);const [v,setV]=useState('');return <div className="overlay"><div className="modalCard"><div className="modalHead"><div><b>{person.nick}</b><span>{person.bot?'Бот-соперник':'Друг'} · сейчас онлайн</span></div><button className="iconAction" onClick={close}><Icon type="close"/></button></div><div className="modalChat">{msgs.map((m,i)=><div className={`chatBubble ${m.r}`} key={i}>{m.t}</div>)}</div><div className="teacherInput"><input value={v} onChange={e=>setV(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&v.trim()){setMsgs(m=>[...m,{r:'me',t:v},{r:'ai',t:'Принято. Давай соревноваться!'}]);setV('')}}} placeholder="Написать сообщение…"/><button className="primary" onClick={()=>{if(v.trim()){setMsgs(m=>[...m,{r:'me',t:v},{r:'ai',t:'Принято. Давай соревноваться!'}]);setV('')}}}>Send</button></div></div></div>}

function Duels({setUser,setAch}){const [started,setStarted]=useState(false);const [q,setQ]=useState(0);const [score,setScore]=useState(0);const qs=[['«Кошка»',['Cat','Dog','Bird','Fish'],0],['Choose correct',['She goes to work.','She go to work.','She going work.','She gone work.'],0],['«Спасибо»',['Gracias','Danke','Merci','Thank you'],3],['Past Simple',['I went home.','I go home yesterday.','I have went home.','I going home.'],0],['«Вода»',['Bread','Water','House','Street'],1]]; if(!started)return <div className="stack"><PageTitle eyebrow="VERSUS / 1V1" title="Дуэли" sub="5 вопросов. Таймер. Победа важнее идеальности, но знания важнее победы."/><div className="duelHero card"><div><div className="versusNo">01</div><h2>Быстрая дуэль</h2><p>Ты vs NOVA Bot. 5 вопросов, 10 секунд на каждый. За победу — 120 XP.</p><button className="primary big" onClick={()=>setStarted(true)}>Начать <Icon type="arrow" size={16}/></button></div><div className="vsGlyph"><span>YOU</span><b>×</b><span>BOT</span></div></div></div>;const cur=qs[q]; if(q>=qs.length)return <div className="stack"><PageTitle eyebrow="MATCH COMPLETE" title={score>=3?'Победа.':'Ещё одна попытка.'} sub={`Результат ${score}/${qs.length}.`}/><section className="card resultCard"><div className="resultNumber">+{score>=3?120:40}</div><div><h2>{score>=3?'Красиво сыграно':'Хорошая тренировка'}</h2><p>Результат добавлен в статистику и историю дуэлей.</p><button className="primary" onClick={()=>{setUser(u=>({...u,xp:u.xp+(score>=3?120:40)}));if(score>=3)setAch(a=>[...new Set([...a,'duelist'])]);setStarted(false);setQ(0);setScore(0)}}>В дуэль снова</button></div></section></div>;return <div className="stack"><PageTitle eyebrow={`MATCH / ${q+1} of ${qs.length}`} title="Выбери ответ" sub="У тебя 10 секунд. Но в демо таймер визуальный — без стресса."/><section className="card testCard"><div className="duelTimer">00:10</div><div className="taskPrompt">{cur[0]}</div><div className="choiceGrid">{cur[1].map((o,i)=><button className="choiceBtn" key={o} onClick={()=>{setScore(s=>s+(i===cur[2]?1:0));setQ(x=>x+1)}}>{o}<span>{String(i+1).padStart(2,'0')}</span></button>)}</div></section></div>}

function Rating({user}){const list=[{nick:user.nick,xp:user.xp,level:user.level,you:true},...FRIENDS,...BOTS].sort((a,b)=>b.xp-a.xp);return <div className="stack"><PageTitle eyebrow="LEADERBOARD" title="Топ игроков" sub="Сезонные результаты. Не рейтинг ради рейтинга — видна скорость и прогресс."/><section className="card ratingCard"><div className="ratingHeader"><span>#</span><span>Игрок</span><span>XP</span><span>Уровень</span></div>{list.map((p,i)=><div className={`ratingRow ${p.you?'you':''}`} key={p.nick}><span className="rank">{String(i+1).padStart(2,'0')}</span><span className="ratingUser"><span className="avatarMini">{p.nick[0].toUpperCase()}</span><b>{p.nick}</b>{p.you&&<small>ты</small>}</span><b>{p.xp}</b><span>LVL {p.level}</span></div>)}</section></div>}

function Achievements({ach}){return <div className="stack"><PageTitle eyebrow="REWARDS" title="Достижения" sub="Награды за реальные действия: учись, практикуйся, помогай друзьям."/><section className="achievementGrid">{ACHIEVEMENTS.map(a=>{const on=ach.includes(a[0]);return <div className={`card achievement ${on?'unlocked':''}`} key={a[0]}><div className="achievementCode">{a[3]}</div><div className="eyebrow">{a[0].toUpperCase()}</div><h3>{a[1]}</h3><p>{a[2]}</p><span className={`status ${on?'success':''}`}>{on?'UNLOCKED':'LOCKED'}</span></div>})}</section></div>}

function Analytics({user}){return <div className="stack"><PageTitle eyebrow="ACTIVITY / 30 DAYS" title="Аналитика" sub="Смотрим не только на XP: какие навыки растут, где ошибаешься и сколько реально учишься."/><div className="metricGrid"><Metric title="Точность" value="72%" suffix="" note="+8% к прошлой неделе"/><Metric title="Время" value="14:32" suffix="ч" note="за последние 30 дней"/><Metric title="Слова" value={user.wordsSaved} suffix="" note="в сохранённом словаре"/><Metric title="Учитель" value={user.teacherQuestions} suffix="" note="вопросов задано"/></div><section className="card chartCard"><div className="cardHeader"><div><div className="eyebrow">ACTIVITY</div><h2>Последние 7 дней</h2></div><span className="tag">+24%</span></div><div className="barChart">{[44,68,38,82,91,63,76].map((v,i)=><div className="barCol" key={i}><span style={{height:`${v}%`}}></span><small>{['Пн','Вт','Ср','Чт','Пт','Сб','Вс'][i]}</small></div>)}</div></section><section className="card"><div className="eyebrow">SKILLS</div><div className="skillRows">{[['Словарь',86],['Грамматика',61],['Чтение',79],['Аудирование',68],['Составление',57]].map(x=><div className="skillRow" key={x[0]}><b>{x[0]}</b><div className="progress"><span style={{width:`${x[1]}%`}}></span></div><span>{x[1]}%</span></div>)}</div></section></div>}

function Profile({user,setUser,close}){const [nick,setNick]=useState(user.nick);const [bio,setBio]=useState(user.bio);return <div className="overlay"><div className="modalCard profileModal"><div className="modalHead"><div><div className="eyebrow">ACCOUNT</div><h2>Профиль</h2></div><button className="iconAction" onClick={close}><Icon type="close"/></button></div><div className="profileTop"><div className="avatarBig">{nick[0]?.toUpperCase()}</div><div><b>{nick}</b><p>{user.xp} XP · уровень {user.level}</p></div></div><label>Никнейм<input className="field" value={nick} onChange={e=>setNick(e.target.value)}/></label><label>Био<textarea className="field" rows="3" value={bio} onChange={e=>setBio(e.target.value)}/></label><label>Фото<input type="file" accept="image/*" className="field"/></label><div className="row end"><button className="secondary" onClick={close}>Отмена</button><button className="primary" onClick={()=>{setUser(u=>({...u,nick,bio}));close()}}>Сохранить</button></div></div></div>}

export default App;
