# NOVA v2 — language platform

NOVA v2 is a responsive React/Vite prototype designed to work as one web app on iPhone, Android, macOS and Windows.

## Local run on a Mac M1

Requirements: Node.js LTS.

```bash
cd NOVA_v2
npm install
npm run dev -- --host
```

Open the local URL on the Mac. To test from iPhone/Android on the same Wi‑Fi, use the Network URL printed by Vite.

Production build:

```bash
npm run build
npm run preview
```

## Design direction

The visual system is intentionally minimal, editorial and monochrome: oversized typography, generous whitespace, fine borders, restrained motion and small mono labels. The uploaded reference video is a Nothing launch-style visual. The exact Nothing typefaces are proprietary; this build uses the freely available Inter Tight + JetBrains Mono pairing as a legally safer approximation. If a properly licensed copy of the exact typeface is obtained, it can be swapped in via CSS variables.

## Included product areas

- Home dashboard and progress
- 9 languages
- 24-module path
- choice / word-building / error-detection exercises
- serious placement-test flow
- offline knowledge-base teacher
- multilingual translation demo
- friends, bots and chat UI
- 1v1 timed duels
- leaderboard
- achievements
- activity analytics
- profile editing + photo selector
- responsive mobile bottom navigation
- light/dark mode

## Important production note

The prototype uses localStorage for demo persistence. It is not a real multi-user backend. For real accounts, cross-device friends, chat and synchronized progress, connect Supabase (Auth + Postgres + Realtime + Storage).

## Free-first stack

- GitHub Free for source control and a public open-source repository.
- GitHub Pages for the static frontend if the repository is public.
- Cloudflare Pages is another strong static-hosting option.
- Supabase Free for an initial database/auth prototype.

Do not commit API keys or service-role secrets to GitHub.

## Suggested production architecture

Frontend: React/Vite or a PWA.
Backend: Supabase Auth + Postgres + Realtime + Storage.
Hosting: Cloudflare Pages or GitHub Pages for the frontend.
Mobile packaging later: Capacitor for iOS/Android.

## Product principles taken from competitor research

1. Keep Duolingo's low-friction daily habit and instant feedback.
2. Avoid over-optimizing for streaks/XP; users should see skill progress too.
3. Use practical vocabulary and real-life scenarios rather than arbitrary sentences.
4. Include grammar explanations and review, as people often praise the structure of Babbel.
5. Add authentic listening/speaking pathways inspired by Memrise's native-speaker emphasis.
6. Add community feedback and CEFR-style milestones inspired by Busuu.
7. Make ads/energy/limits non-invasive in the core learning flow.
8. Keep competition optional; learning progress must remain visible without a leaderboard.
