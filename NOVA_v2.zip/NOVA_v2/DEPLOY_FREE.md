# NOVA — бесплатный путь от MacBook до публичного сайта

## 1. GitHub

Создай аккаунт на github.com. Создай **Public repository** `nova-language-platform`.

Загрузить проект можно через сайт GitHub (Add file → Upload files), поэтому Git вообще можно не знать на первом этапе.

Для нормальной работы на Mac лучше установить Git и использовать VS Code или Cursor.

## 2. Git на Mac — минимальный набор

```bash
git init
git add .
git commit -m "NOVA v2"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/nova-language-platform.git
git push -u origin main
```

## 3. Бесплатный preview

### GitHub Pages
Подходит для статического frontend. Для GitHub Free репозиторий должен быть публичным. После включения Pages GitHub Actions может собирать и публиковать проект.

### Cloudflare Pages
Подключи GitHub repository, выбери Vite build:
Build command: `npm run build`
Output directory: `dist`

### Vercel
Очень удобен для разработки и preview, но проверь условия Hobby: бесплатный Hobby предназначен для personal/non-commercial use. Для коммерческого массового продукта не рассчитывай на него как на бесплатную производственную инфраструктуру.

## 4. Настоящие аккаунты

Создай Supabase project. Подключи Auth, Postgres, Realtime и Storage. SQL из `SUPABASE_SCHEMA.sql` — стартовая схема.

## 5. Когда появятся реальные пользователи

Frontend останется тем же. Заменяем localStorage на:
- Supabase Auth — регистрация/вход
- Postgres — профили, прогресс, друзей, достижения
- Realtime — чат и дуэли
- Storage — аватары

## 6. iPhone/Android

Пока публичный PWA-сайт: Safari/Chrome → добавить на главный экран.

Нативные приложения позже можно собирать через Capacitor, не переписывая основную React-логику.
